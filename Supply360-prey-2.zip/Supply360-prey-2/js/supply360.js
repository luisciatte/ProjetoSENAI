const sidebar = document.getElementById('default-sidebar');
const contentWrapper = document.getElementById('content-wrapper');
const sidebarToggleButton = document.querySelector('[data-drawer-toggle="default-sidebar"]');
sidebarToggleButton.addEventListener('click', function () {
    sidebar.classList.toggle('-translate-x-full');
    contentWrapper.classList.toggle('ml-0');
    contentWrapper.classList.toggle('ml-64');
});

document.addEventListener('click', function (event) {
    if (!sidebar.contains(event.target) && !sidebarToggleButton.contains(event.target)) {
        sidebar.classList.add('-translate-x-full');
        contentWrapper.classList.remove('ml-64');
        contentWrapper.classList.add('ml-0');
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const dropdownButton = document.getElementById('example-dropdown-button');
    const dropdownMenu = document.getElementById('example-dropdown');

    dropdownButton.addEventListener('click', function () {
        dropdownMenu.classList.toggle('hidden');
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('dropdown');
    const modalToggle = document.querySelector('[data-dropdown-toggle="dropdown"]');
    const modalClose = modal.querySelector('button');
    modalToggle.addEventListener('click', function () {
        modal.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    });
    modalClose.addEventListener('click', function () {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('createProductModal');
    const modalToggle = document.querySelector('[data-modal-toggle="createProductModal"]');
    const modalClose = modal.querySelector('button');
    modalToggle.addEventListener('click', function () {
        modal.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    });
    modalClose.addEventListener('click', function () {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
    const productForm = document.getElementById('productForm');
    productForm.addEventListener('submit', function (event) {
        event.preventDefault();
        console.log('Form submitted');
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('updateProductModal');
    const modalToggle = document.querySelector('[data-modal-toggle="updateProductModal"]');
    const modalClose = modal.querySelector('button');
    modalToggle.addEventListener('click', function () {
        modal.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    });
    modalClose.addEventListener('click', function () {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
    const productForm = document.getElementById('productForm');
    productForm.addEventListener('submit', function (event) {
        event.preventDefault();
        console.log('Form submitted');
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const addProductBtn = document.getElementById('add-product-btn');
    const produtosContainer = document.getElementById('produtos-container');
    const modal = document.getElementById('modal');
    const closeModalBtn = document.getElementById('close-modal-btn');

    addProductBtn.addEventListener('click', () => {
        const newItem = document.createElement('div');
        newItem.className = 'flex flex-col space-y-4 item';
        newItem.innerHTML = `
            <label for="produto" class="block mb-2 text-sm font-medium text-blazeOrange">Produtos</label>
            <select name="produto[]" class="produto-select bg-white border border-blazeOrange text-blazeOrange text-sm rounded-lg focus:ring-blazeOrange focus:border-blazeOrange block w-full p-2.5" required>
                <option value="" disabled selected>Escolha um produto</option>
                <!-- Aqui você adicionaria as opções de produtos dinamicamente -->
                <option value="produto1">Produto 1</option>
                <option value="produto2">Produto 2</option>
                <option value="produto3">Produto 3</option>
            </select>
            
            <label for="quantidade" class="block mb-2 text-sm font-medium text-blazeOrange">Quantidade</label>
            <input type="number" name="quantidade[]" class="quantidade-input bg-white border border-blazeOrange text-blazeOrange text-sm rounded-lg focus:ring-blazeOrange focus:border-blazeOrange block w-full p-2.5" placeholder="Digite a quantidade" step="0.01" required>
            
            <button type="button" class="remove-btn bg-red-500 text-white p-2 rounded-lg hover:bg-red-600">Remover</button>
        `;
        produtosContainer.appendChild(newItem);

        // Attach remove functionality to the newly added item
        newItem.querySelector('.remove-btn').addEventListener('click', () => {
            newItem.remove();
        });
    });

    // Attach remove functionality to existing items
    produtosContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-btn')) {
            e.target.parentElement.remove();
        }
    });

    // Open Modal
    document.querySelector('#open-modal-btn').addEventListener('click', () => {
        modal.classList.remove('hidden');
    });

    // Close Modal
    closeModalBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('readProductModal');
    const modalToggle = document.querySelector('[data-modal-toggle="readProductModal"]');
    const modalClose = modal.querySelector('button');
    modalToggle.addEventListener('click', function () {
        modal.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    });
    modalClose.addEventListener('click', function () {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('deleteModal');
    const modalToggle = document.querySelector('[data-modal-toggle="deleteModal"]');
    const modalClose = modal.querySelector('button');
    modalToggle.addEventListener('click', function () {
        modal.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    });
    modalClose.addEventListener('click', function () {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    });
});